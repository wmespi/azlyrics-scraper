from fake_useragent.fake import FakeUserAgent, UserAgent  # noqa # isort:skip
from fake_useragent.errors import (
    FakeUserAgentError,
    UserAgentError,
)  # noqa # isort:skip
from fake_useragent.settings import __version__ as VERSION  # noqa # isort:skip
