# coding:utf-8
from __future__ import unicode_literals, absolute_import
from .base_object import BaseObject


class Invite(BaseObject):
    """Represents the invite"""

    _item_type = 'invite'
