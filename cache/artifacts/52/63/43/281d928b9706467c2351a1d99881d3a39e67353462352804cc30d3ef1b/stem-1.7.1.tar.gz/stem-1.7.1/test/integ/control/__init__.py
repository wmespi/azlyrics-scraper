"""
Integration tests for stem.control.
"""

__all__ = ['base_controller', 'controller']
