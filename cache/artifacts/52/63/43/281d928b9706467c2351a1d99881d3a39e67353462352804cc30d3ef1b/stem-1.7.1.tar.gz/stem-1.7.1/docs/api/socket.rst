Control Socket
==============

.. automodule:: stem.socket

