"""
Integration tests for stem.response.
"""

__all__ = ['protocolinfo']
