"""
Unit tests for stem.exit_policy.py contents.
"""

__all__ = ['policy', 'rule']
