# TODO: This module (hidden_service_descriptor) is a temporary alias for
# hidden_service. This alias will be removed in Stem 2.x.

from stem.descriptor.hidden_service import *
