from unidecode.util import main

main()
